# change the directory to indicate the location of this file and the 'datasets' folder on your machine
setwd("/Users/.../Desktop/Rcode_ggplot_tutorial/")

# install.packages('ggplot2')
library(ggplot2)


## -- Structure of this tutorial
  # Getting Started
      #   conceptual overview of ggplot, and some basic plots 
      #   adding regression lines and other basic embellishments 
      #   grouping and statistically transforming data 
      #   cosmetic details (e.g., colour, legends, axis labels) 
  # Visualizing Linguistic Data
      #   formant data and vowel plots 
      #   barplots, lineplots, and error bars 
      #   binomial variables and plotting proportions 
      #   geospatial plotting and possibilities for students of variation 
      

## -- What is ggplot?
# "ggplot2 is a plotting system for R, based on the grammar of graphics, which tries to <b>take the good parts of base and lattice graphics and none of the bad parts. It takes care of many of the fiddly details that make plotting a hassle (like drawing legends) as well as providing a powerful model of graphics that makes it easy to produce complex multi-layered graphics."
#  Hadley Wickham, developer, http://ggplot2.org/




## --------------------------------------------------------- ##
#  Basic plots

## -- Let's start with a simple data set
# mtcars is a built in data set. 
head(mtcars)

	# Let's tidy it up a bit
	# turn rownames (car model) into vector, and select a subset of columns
	df1 <- data.frame(model = as.factor(row.names(mtcars)), 
	                  mtcars[,c(11,1:2,4,6)])
	row.names(df1) <- NULL

	head(df1)



# A simple "scatterplot"
ggplot(data = df1, aes(x = cyl, y = mpg, group = cyl)) +
  geom_point()



## -- A simple boxplot
ggplot(data = df1, aes(x = cyl, y = mpg, group = cyl)) +
  geom_boxplot()



## -- A simple violin plot
ggplot(data = df1, aes(x = cyl, y = mpg, group = cyl)) +
  geom_violin()



## -- Default axis format isn't always very readable
# adjust formatting of x- and y- axes. 
ggplot(data = df1, aes(x = cyl, y = mpg, group = cyl)) +
  geom_violin() +
  # change font size, font color, and axis label position
  theme(axis.text = element_text(colour="black", size=15),
        axis.title.x=  element_text(face="bold", size=18, vjust=-0.45),
        axis.title.y = element_text(size=18, vjust=.2),
        axis.ticks = element_line(colour="red"))




## -- Define theme for easy use later
my.theme <- theme(axis.text = element_text(colour="black", size=15),
                  text = element_text(size=16),
                  title = element_text(size=19),
                  axis.title.x=  element_text(vjust=-0.45),
                  axis.title.y = element_text(vjust=.2),
                  axis.ticks = element_line(colour="black"),
                  axis.line = element_line())




## -- Combining geoms
ggplot(data = df1, aes(x = cyl, y = mpg, group = cyl)) +
  geom_violin() +
  geom_point() + # add a layer showing raw data points
  my.theme # use the custom theme we just defined




## -- Adjust parameters of one layer independently
ggplot(data = df1, aes(x = cyl, y = mpg, group = cyl)) +
  geom_violin() +
  geom_point(position=position_jitter(width=.1)) + # add jitter to points
  my.theme




## -- Try a different representation of points
ggplot(data = df1, aes(x = cyl, y = mpg, group = cyl)) +
  geom_violin() +
  geom_dotplot(binaxis = "y", stackdir = "center") + # specify which axis to use for 'binning'
  my.theme




## -- ... so, those dots were a little big
ggplot(data = df1, aes(x = cyl, y = mpg, group = cyl)) +
  geom_violin() +  
  geom_dotplot(binaxis = "y", stackdir = "center", dotsize = .65) + # change size of dots
  my.theme







## ----------------------------------------------------------------- ##
#  Basic Embellishments 

## -- Add descriptive stats to boxplots
ggplot(data = df1, aes(x = cyl, y = mpg, group = cyl)) +
  geom_boxplot() +
  # fun.y=mean calculates the mean of the y-axis variable (mpg) for each group.  
  # geom="point" indicates means should be plotted as points over top of the boxplots.
  stat_summary(fun.y = mean, geom = "point", color = "red", size = 3) +
  my.theme





## -- Scatterplot with loess-smoothed curve and labelled axes
ggplot(data = df1, aes(x = hp, y = wt)) +
  geom_point() + # make scatterpot
  geom_smooth() + # add loess line
  scale_x_continuous("gross horsepower") + # change axis labels and limits
  scale_y_continuous("weight (lb/1000)", limits = c(1,6)) +
  my.theme




## -- Remove error ribbon
ggplot(data = df1, aes(x = hp, y = wt)) +
  geom_point() + 
  geom_smooth(se = FALSE) + # remove error ribbon
  scale_x_continuous("gross horsepower") +
  scale_y_continuous("weight (lb/1000)", limits = c(1,6)) +
  my.theme



## -- Change error ribbon to pointrange
ggplot(data = df1, aes(x = hp, y = wt)) +
  geom_point() +
  stat_smooth(geom = "pointrange") + # note the change to stat_smooth()
  scale_x_continuous("gross horsepower") +
  scale_y_continuous("weight (lb/1000)", limits = c(1,6)) +
  my.theme




## -- Plot a linear best-fit line instead of a nonlinear curve
ggplot(data = df1, aes(x = hp, y = wt)) +
  geom_point() +
  geom_smooth(method = "lm", formula = y~(x)) +
  scale_x_continuous("gross horsepower") +
  scale_y_continuous("weight (lb/1000)", limits = c(1,6)) +
  my.theme



## -- Annotate the plot
ggplot(data = df1, aes(x = hp, y = wt)) +
  geom_point() +
  geom_smooth(method = "lm", formula = y~(x)) +
  scale_x_continuous("gross horsepower") +
  scale_y_continuous("weight (lb/1000)", limits = c(1,6)) +
  # specify the text (i.e., label) and the x- and y-coordinates for text placement
  annotate(geom = "text", x = 250, y = 2, label = "R2 = ???, p = ???", color = "red") +
  my.theme


# The problem of annotating plots manually...
# if your data set is continually changing (say, as you run more participants), you must continually hand correct the annotations
# this is cumbersome, and it's easy to make mistakes
# **SOLUTION**: supply the *label* argument with output directly from regression model
# let's see an example


## -- First, examine the model plotted by geom_smooth 
# Recall, we had previously specified geom_smooth(method="lm", formula=y~(x)). The call below produces the same model, just outside of ggplot.
my.model <- summary(lm(wt ~ hp, data=df1))
print(my.model)



## -- Next, let's extract values from this model 
# extract the R-squared value for the weight~horsepower correlation
my.model.r2 = my.model$r.squared

print(my.model.r2)
# combine R-squared value into a descriptive string
my.exp <- paste("R2 =", my.model.r2, sep=" ")

print(my.exp)




## -- Now, annotate plot with this model output
ggplot(data = df1, aes(x = hp, y = wt)) +
  geom_point() +
  geom_smooth(method = "lm", formula = y~(x)) +
  scale_x_continuous("gross horsepower") +
  scale_y_continuous("weight (lb/1000)", limits = c(1,6)) +
  # We no longer specify the annotation text locally. 
  # The text comes directly from the regression model.
  annotate(geom = "text", x = 250, y = 2, label = my.exp, color = "red")+
  my.theme



## -- Extract and format multiple values simultaneously
lm_eqn = function(df1){
    m = lm(wt ~ hp, df1);
    eq <- substitute(italic(y) == a + b %.% italic(x)*","
                     
                     ~~italic(r)^2~"="~r2~~", p < "~~p, 
         list(a = format(coef(m)[1], digits = 2),
              b = format(coef(m)[2], digits = 2),              
              r2 = format(summary(m)$r.squared, digits = 3),              
              p = format(coef(summary(m))[8], digits = 3, scientific=FALSE)             
              ))
    as.character(as.expression(eq));                 
}
# Credit goes to Ramnath Vaidyanathan for this function. Go [here](http://stackoverflow.com/questions/7549694/ggplot2-adding-regression-line-equation-and-r2-on-graph) for the original post on StackOverflow.



## -- Advanced annotation strategy
ggplot(data = df1, aes(x = hp, y = wt)) +
  geom_point() +
  geom_smooth(method = "lm", formula = y~(x)) +
  scale_x_continuous("gross horsepower") +
  scale_y_continuous("weight (lb/1000", limits = c(1,6)) +
  annotate(geom = "text", x = 250, y = 2, label = lm_eqn(df1), parse = T, color = "red") +
  my.theme







## ----------------------------------------------------------------- ##
#  Grouping and Statistically Transforming Data
    # log transformations
    # add regresssion lines in log space
    # add separate regression lines for data subsets
    # histograms, density distributions, and faceting

## -- Let's use a larger data set
df2 <- subset(diamonds, carat > 0.5)

head(df2)
nrow(df2)



## -- A linear best-fit line, again
ggplot(data = df2, aes(x = carat, y = price)) +
  geom_point() +
  geom_smooth(method = "lm") +
  scale_x_continuous("carat") +
  scale_y_continuous("price")+
  my.theme




## -- Log transform the x- and y- <font color=blue> scale system </font>
ggplot(data = df2, aes(x = log10(carat), y = log10(price))) +
  geom_point() +
  geom_smooth(method = "lm") +
  scale_x_continuous("log10(carat)") +
  scale_y_continuous("log10(price)") +
  my.theme




## -- Log transform the x- and y- <font color=blue> coordinate system </font>
ggplot(data = df2, aes(x = carat, y = price)) +
  geom_point() +
  geom_smooth(method = "lm") +
  coord_trans(x = "log10", y = "log10") +
  scale_x_continuous("log10(carat)") +
  scale_y_continuous("log10(price)") +
  my.theme




## -- Use color to depict subset groupings
ggplot(data=df2, aes(x=carat, y=price, colour=cut, fill=cut)) +
  geom_point() +
  geom_smooth(method = "lm") +
  coord_trans(x = "log10", y = "log10") +
  scale_x_continuous("log10(carat)") +
  scale_y_continuous("log10(price)") +
  my.theme




## -- Adjust the alpha transparency of points
ggplot(data=df2, aes(x=carat, y=price, colour=cut, fill=cut)) +
  geom_point(alpha = .05) + # number btw 0 (transparent) and 1 (opaque)
  geom_smooth(method = "lm") +
  coord_trans(x = "log10", y = "log10") +
  scale_x_continuous("log10(carat)") +
  scale_y_continuous("log10(price)") +
  my.theme




## -- Reverse legend so order better matches plot
ggplot(data=df2, aes(x=carat, y=price, colour=cut, fill=cut)) +
  geom_point(alpha = .05) +
  geom_smooth(method = "lm") +
  coord_trans(x = "log10", y = "log10") +
  scale_x_continuous("log10(carat)") +
  scale_y_continuous("log10(price)") +
  guides(fill = guide_legend(reverse = TRUE), colour = guide_legend(reverse = TRUE)) +
  my.theme




## -- Histogram
# plot number of tokens (counts) that fall within a specific bin
ggplot(data=df2, aes(x=price, fill=cut, colour=cut)) +
  geom_histogram(alpha=.8) +
  guides(fill = guide_legend(reverse = TRUE), colour = guide_legend(reverse = TRUE)) +
  my.theme




## -- Density distribution
# plot the probability that a variable will take on a given value
ggplot(data=df2, aes(x=price, fill=cut, colour=cut)) +
  geom_density(alpha=.5) +
  guides(fill = guide_legend(reverse = TRUE), colour = guide_legend(reverse = TRUE)) +
  my.theme




## -- Histogram overlaid with density distribution
# the trick here is to change the y-axis for the histrogram
# from counts to probability density
ggplot(data=df2, aes(x=price)) +
  geom_histogram(aes(y=..density..), alpha=.5) +
  geom_density(size=1.25) +
  my.theme




## -- Adjust the bandwidth for the kernel density estimation
ggplot(data=df2, aes(x=price)) +
  geom_histogram(aes(y=..density..), alpha=.5) +
  geom_density(size=1.25, adjust=1.9) +
  my.theme




## -- Map a color gradient to counts
ggplot(data=df2, aes(x=price, fill=..count..)) +
  geom_histogram() +
  scale_fill_continuous(low="violet", high="violetred4") +
  my.theme



## -- Histograms split by variable
# define subset for easy reference
df2.sub <- subset(df2, cut %in% c("Ideal","Good") & price < 8000)

ggplot(data=df2.sub, aes(x=price, colour=cut)) +
  geom_histogram(aes(y=..density.., fill=cut), alpha=.3) +
  geom_density(size=1.5) +
  facet_grid(cut ~ .) +
  my.theme




## -- Embellish histograms
# calculate means of each group
df2.sub.means <- ddply(df2.sub, .(cut), summarise, mean.price=mean(price))

print(df2.sub.means)

ggplot(data=df2.sub, aes(x=price, colour=cut)) +
  geom_histogram(aes(y=..density.., fill=cut), alpha=.3) +
  geom_density(size=1.5) +
  geom_vline(data=df2.sub.means, aes(xintercept=mean.price),
             linetype="dashed", size=1, colour="red") + 		# add means as dashed lines
  facet_grid(cut ~ .) + 										# plot subgroups as separate "facets"
  my.theme




## ----------------------------------------------------------------- ##
#  Some Cosmetic Details about ggplot

## -- Color palettes
gg_color_hue <- function(n) {
  hues = seq(15, 375, length=n+1)
  hcl(h=hues, l=65, c=100)[1:n]
}

	par(mfrow=c(1,2))
	pie(rep(1,40), col=rainbow(40), labels="", border=NA, radius=1, main="R's default \n color palette")
	
	pie(rep(1,40), col=gg_color_hue(40), labels="", border=NA, radius=1, main="default ggplot palette \n luminance=65, chorma=100")




## -- ggplot color selection -- maximal dispersion
gg_color_hue <- function(n) {
  hues = seq(15, 375, length=n+1)
  hcl(h=hues, l=65, c=100)[1:n]
}

	par(mfrow=c(2,3))
	pie(rep(1,40), col=gg_color_hue(40), labels="", border=NA, radius=1, main="default palette \n luminance=65, chorma=100")
	
	pie(rep(1,2), col=gg_color_hue(2), init.angle=270, border=NA, radius=1, main="default coloring \n for factor with 2 levels")
	
	pie(rep(1,3), col=gg_color_hue(3), init.angle=300, border=NA, radius=1, main="default coloring \n for factor with 3 levels")
	
	pie(rep(1,4), col=gg_color_hue(4), init.angle=330, border=NA, radius=1, main="default coloring \n for factor with 4 levels")
		
	pie(rep(1,5), col=gg_color_hue(5), init.angle=330, border=NA, radius=1, main="default coloring \n for factor with 5 levels")
	
	pie(rep(1,6), col=gg_color_hue(6), init.angle=330, border=NA, radius=1, main="default coloring \n for factor with 6 levels")




## -- Number of factor levels determines colors
ggplot(mtcars, aes(x = factor(cyl), fill = factor(cyl))) + 
  geom_bar() +
  my.theme

ggplot(mpg, aes(x = trans, fill = trans)) + 
  geom_bar() +
  my.theme



## -- Change color palette using color names
ggplot(mtcars, aes(x = factor(cyl), fill = factor(cyl))) + 
  geom_bar() +
  scale_fill_manual(values=c("red", "green", "blue")) +
  my.theme




## -- Change color palette using hexidecimal notation
ggplot(mtcars, aes(x = factor(cyl), fill = factor(cyl))) + 
  geom_bar() +
  scale_fill_manual(values=c("#980000", "#009800", "#000098")) +
  my.theme



## -- Use pre-defined palette from RColorBrewer
ggplot(mtcars, aes(x = factor(cyl), fill = factor(cyl))) + 
  geom_bar() +
  scale_fill_brewer() +
  my.theme



## -- Select specific palette from RColorBrewer
ggplot(mtcars, aes(x = factor(cyl), fill = factor(cyl))) + 
  geom_bar() +
  scale_fill_brewer(palette="YlOrRd")+
  my.theme


## -- Render image in grayscale
ggplot(mtcars, aes(x = factor(cyl), fill = factor(cyl))) + 
  geom_bar() +
  scale_fill_grey() +
  my.theme


## -- Change legend name
ggplot(mtcars, aes(x = factor(cyl), fill = factor(cyl))) + 
  geom_bar() +
  scale_fill_grey("Cylinders") +
  my.theme


## -- Every element in a plot is customizable
ggplot(mtcars, aes(x = factor(cyl), fill = factor(cyl))) + 
  geom_bar() +
  scale_fill_grey("Cylinders") +
  theme(legend.position="bottom",              # move legend below x-axis
        legend.title = element_text(colour="red", face="italic", size=19),
        legend.text = element_text(size=17), 
        axis.text.x = element_text(colour="red", face="bold", size=17),
        axis.title.x = element_blank(),        # remove x-axis label
        panel.background = element_blank(),     # remove panel grid
        axis.line = element_line()  # add 'l-shaped' axis line
        ) 





## ----------------------------------------------------------------- ##
#  Linguistic data: Part 1
#  Formant Values and Vowel Plots

## -- Peterson and Barney (1952) vowel data
# acoustic measurements of 8 reps of 10 vowels from 72 speakers (adults and children)
pb <- read.delim("http://ling.upenn.edu/courses/cogs501/pb.Table1", header = FALSE)

	# Give meaningful column names
	colnames(pb) <- c("Age","Sex","Speaker","Vowel","V1","F0.hz","F1.hz","F2.hz","F3.hz")

	# Relabel the age data
	levels(pb$Age) <- c("Child","Adult","Adult")
	pb$Age <- relevel(pb$Age, "Adult")

	# Clean up speaker labeling
	pb$Speaker <- as.factor(paste("S", pb$Speaker, sep=""))

	head(pb)


## -- A vowel plot of one speaker's data
# note we can select a subset from within the call to ggplot
ggplot(data=subset(pb, Speaker=="S2"), aes(x=F2.hz, y=F1.hz, label=Vowel)) +
  geom_point() +
  geom_text() +  # geom_text() labels points. Label must be specified as an aesthetic
  scale_y_reverse() +   # reverse the axes
  scale_x_reverse() +
  my.theme



## -- Label placement was bad on that last one. Let's fix it!
# note we can select a subset from within the call to ggplot
ggplot(data=subset(pb, Speaker=="S2"), aes(x=F2.hz, y=F1.hz, label=Vowel)) +
  geom_point() +
  geom_text(hjust=1.1, vjust=-.2, size=5.5) + # adjust placement and size of labels
  scale_y_reverse() +
  scale_x_reverse() +
  my.theme



## -- Plot multiple speakers individually
ggplot(data=subset(pb, Speaker %in% c("S1","S2","S3","S4")), aes(x=F2.hz, y=F1.hz, label=Vowel)) +
  geom_text(hjust=1, vjust=-.2) + 
  scale_y_reverse() +
  scale_x_reverse() +
  facet_wrap(~ Speaker) + # this line provides functionality similar to the lattice package
  my.theme



## -- More complex faceting
ggplot(data=pb, aes(x=F2.hz, y=F1.hz, label=Vowel, colour=Vowel)) +
  geom_text(hjust=1, vjust=-.2) + 
  scale_y_reverse() +
  scale_x_reverse() +
  facet_wrap(~ Sex + Age) + # specify multiple variables for faceting
  my.theme



## -- Adjust range of reversed axes
ggplot(data=pb, aes(x=F2.hz, y=F1.hz, label=Vowel, colour=Vowel)) +
  geom_text(hjust=1, vjust=-.2) + 
  scale_y_reverse() +
  scale_x_reverse() +
  coord_cartesian(ylim=c(0, 1500)) +
  facet_wrap(~ Sex + Age) +
  my.theme




## -- Plot all females by age
ggplot(data=subset(pb, Sex=="f"), aes(x=F2.hz, y=F1.hz, label=Vowel, colour=Age)) +
  geom_text() +
  scale_y_reverse() +
  scale_x_reverse() +
  my.theme




## -- Convex hulls
require(plyr)
# chull() is a function for finding the "envelope" of a set of data points. Here we use this function to find the extreme points for a 2-dimensional space (F1-F2)
find_hull <- function(df) {df[chull(df$F2.hz, df$F1.hz),]}

# apply this function to find the envelope for females by Age (adult vs. children)
hulls <- ddply(subset(pb, Sex=="f"), .(Age), find_hull)

print(hulls)



## -- Using convex hulls in plots
ggplot(data=subset(pb, Sex=="f"), aes(x=F2.hz, y=F1.hz, label=Vowel, colour=Age, fill=Age)) +  
  geom_text() +
  geom_polygon(data=hulls, alpha=.4) +
  scale_y_reverse() +
  scale_x_reverse() +
  my.theme






## ----------------------------------------------------------------- ##
#  Linguistic data: Part 2
#  Response Times, Barplots, and Error Bars


## -- One way to calculate standard error of the mean
std.error <- function(x, na.rm=T) {
  sqrt(var(x, na.rm=na.rm) / length(x[complete.cases(x)]))
}



## -- A fake data set
# read in fake data
rt.dat <- read.delim("datasets/fakedata.txt", header=T)

	head(rt.dat)
	
	# How many data points per subjet per condition
	table(rt.dat$IV1, rt.dat$IV2) / length(unique(rt.dat$Subject))



## -- Calculate subject-wise condition means
require(plyr)

	# use ddply() to calculate condition means for each subject, averaging over items
	mean.bySubj <- ddply(rt.dat, .(Subject, IV1, IV2), summarise, 
                     "mean.RT" = mean(RT))

	head(mean.bySubj, 18)



## -- Calculate grand means and std.error of the mean
grand.means <- ddply(mean.bySubj, .(IV1, IV2), summarise, 
                     "grand.RT" = mean(mean.RT), 
                     "se" = std.error(mean.RT))

	print(grand.means)



## -- Bar plot showing group means and standard error
ggplot(data = grand.means, aes(x = factor(IV2), y = grand.RT, fill = IV1)) +
  geom_bar(position = position_dodge(.9)) + # position bars side-by-side (cf. stacked)
  geom_errorbar(position = position_dodge(.9), width = .25, 
                aes(ymin = grand.RT-se, ymax = grand.RT+se)) + # ymax and ymin are group mean +/- std. error
  my.theme




## -- If x-axis levels are meaningfully related, try a line graph
ggplot(data = grand.means, aes(x = factor(IV2), y=grand.RT, group=IV1, colour=IV1)) +
  geom_point() + # use points and lines instead of geom_bar()
  geom_line() +
  # note: we no longer need to specify position_dodge for the errorbars
  geom_errorbar(width = .15, aes(ymin = grand.RT-se, ymax = grand.RT+se)) +
  my.theme



## -- Change linetype
ggplot(data = grand.means, aes(x = factor(IV2), y=grand.RT, group=IV1, colour=IV1)) +
  geom_point() +
  geom_line(linetype="dashed") +
  geom_errorbar(width = .15, aes(ymin = grand.RT-se, ymax = grand.RT+se)) +
  my.theme



## -- A Brief Digression -- Or, Why Averaging over Subjects is Crucial: A Story in Two Parts
# immediately calculate condition means and error from raw data, without first averaging over subjs    
means.wrong <- ddply(rt.dat, .(IV1, IV2), summarise, "mean.RT" = mean(RT))
error.wrong <- ddply(rt.dat, .(IV1,IV2), summarise, "se" = std.error(RT))

	# merge means and error into one frame  
	wrong.grand <- merge(means.wrong, error.wrong, by=c("IV1", "IV2"), all=T)

	print(wrong.grand)



## -- Why averaging over subjects is crucial, cont'd.
require(gridExtra)
plot1<- 
  ggplot(data = grand.means, aes(x = factor(IV2), y=grand.RT, group=IV1, colour=IV1)) +
  geom_point() + 
  geom_line() +
  geom_errorbar(width = .15, aes(ymin = grand.RT-se, ymax = grand.RT+se)) +
  coord_cartesian(ylim=c(600,1600)) +
  ggtitle("the right way") +
  theme(legend.position=c(.1,.8)) +
  my.theme

plot2<- ggplot(data = wrong.grand, aes(x = factor(IV2), y=mean.RT, group=IV1, colour=IV1)) +
  geom_point() +
  geom_line() +
  geom_errorbar(width = .15, aes(ymin = mean.RT-se, ymax = mean.RT+se)) +
  coord_cartesian(ylim=c(600,1600)) +
  ggtitle("the wrong way") +
  theme(legend.position=c(.1,.8)) +
  my.theme

grid.arrange(plot1, plot2, ncol=2, main="standard error the mean")







## ----------------------------------------------------------------- ##
#  Linguistic data: Part 3
#  Binomial DVs and Proportions



## -- The lexdec data set
## lexdec is a canned lexical decision data set from Harold Baayen and Jen Hay  
## available in the package languageR

#install.packages('languageR')
require(languageR)

# numeric coding of of whether response was correct or incorrect
lexdec$Correct.num <- ifelse(lexdec$Correct=="correct", 1, 0)

	# simplify column names
	colnames(lexdec)[c(5,10)] <- c("NativeLang", "Freq")

	# select specific subset for illustrative purposes
	subjs <- c("A1","A2","C","K","R3","S","T1","J","M2","T2","V","Z")
	lex.sub <- subset(lexdec, Subject %in% subjs)

str(lex.sub)



## -- Accuracy by word freq and subject's native language
ggplot(data = lex.sub, aes(x=Freq, y=Correct.num, colour=NativeLang, fill=NativeLang)) +
  geom_point() +
  # fit data with a logistic regression line
  geom_smooth(method="glm", family="binomial", formula=y~(x)) +
  scale_y_continuous("Proportion correct") +
  scale_x_continuous("Word Frequency") +
  my.theme



## -- When logistic regression isn't specified in the smoother
ggplot(data = lex.sub, aes(x=Freq, y=Correct.num, colour=NativeLang, fill=NativeLang)) +
  geom_point() +
  geom_smooth() +
  scale_y_continuous("Proportion correct") +
  scale_x_continuous("Word Frequency") +
  my.theme




## -- Subject-wise proportions for factors
# calculate proportion correct for each subject as a function of whether the previous type was a word or nonword
props.bySubj <- ddply(lex.sub, .(Subject, NativeLang, PrevType), function(x){sum(x$Correct.num)/nrow(x)})

	# change name of the proportion columns
	names(props.bySubj)[names(props.bySubj)=="V1"] <- "Prop"
	
	print(props.bySubj)


## -- Bootstrapped confidence intervals
ggplot(data = props.bySubj, aes(x = PrevType, y = Prop, colour = NativeLang)) +
  stat_summary(fun.data = "mean_cl_boot", size = 1.4) +
  my.theme



## -- Barplot with ootstrapped confidence intervals
ggplot(data = props.bySubj, aes(x = PrevType, y = Prop, fill = NativeLang)) +
  stat_summary(position=position_dodge(.9), fun.y=mean, geom="bar") +
  stat_summary(position=position_dodge(.9), fun.data = "mean_cl_boot", geom="errorbar", width=.25, colour="black") +
  my.theme




## -- An alternate approach
## -- Grand mean proportion and se over subject means
# calculate grand mean and standard error by native language and previous word type
grand.props <- ddply(props.bySubj, .(NativeLang, PrevType), summarise, "mean.prop"=mean(Prop), "se"=std.error(Prop))

print(grand.props)



## -- Barplot of proportions
ggplot(data = grand.props, aes(x = PrevType, y = mean.prop, fill = NativeLang)) +
  geom_bar(position = position_dodge(.9)) +
  geom_errorbar(position = position_dodge(.9), width = .25, 
                aes(ymin = mean.prop-se, ymax = mean.prop+se)) +
  my.theme




## ----------------------------------------------------------------- ##
#  Linguistic data: Part 4
#  Geospatial Plotting and Possibilities for Sociolinguistics and Dialectology


## -- The maps package contains lots of geospatial data
# install.packages("maps")
require(maps)

# collect longitude and latitude coordinates for US states
states <- map_data("state")

	head(states)



## -- Plot a map of the United States
ggplot(data=states, aes(map_id = region, group="group")) + 
    geom_map(map = states) + 
    expand_limits(x = states$long, y = states$lat)




## -- Adjust colors and coordinate space
ggplot(data=states, aes(map_id = region, group="group")) + 
    # colour affects border, fill affects state regions
    geom_map(color="#757575", fill="lightgray", map = states) + 
    expand_limits(x = states$long, y = states$lat) + 
    coord_map() 
 



## -- Read in random latitidue-longitude coordinates
geo.dat <- read.delim("datasets/fakedata_geo.txt", header=T)

	head(geo.dat)
	str(geo.dat)




## -- Overlay points on the map
ggplot(data=states, aes(map_id = region, group="group")) + 
    geom_map(color="#757575", fill="lightgray", map = states) + 
    expand_limits(x = states$long, y = states$lat) + 
    coord_map() +
    geom_point(data = geo.dat, aes(x=long, y=lat, colour=group)) # HERE'S THE MAGIC! 




## -- Remove axes and panel background
ggplot(data=states, aes(map_id = region, group="group")) + 
    geom_map(color="#757575", fill="lightgray", map = states) + 
    expand_limits(x = states$long, y = states$lat) + 
    coord_map() + 
    geom_point(data = geo.dat, aes(x=long, y=lat, colour=group)) + 
    theme(panel.background = element_blank(),  # remove panel background
          axis.ticks = element_blank(),
          axis.text = element_blank(),
          axis.title = element_blank())
